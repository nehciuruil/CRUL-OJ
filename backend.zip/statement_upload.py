import os
import json
from supabase import create_client

def sync_problems_from_markdown(supabase_url: str, supabase_key: str, testdata_base_path: str = "./testdata"):
    supabase = create_client(supabase_url, supabase_key)
    for problem_id in os.listdir(testdata_base_path):
        problem_path = os.path.join(testdata_base_path, problem_id)
        if not os.path.isdir(problem_path):
            continue
        md_file = os.path.join(problem_path, "problem.md")
        if not os.path.exists(md_file):
            continue
        try:
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            lines = content.split('\n')
            problem_name = problem_id
            print(lines[0])
            if lines and lines[0].startswith('#'):
                problem_name = lines[0][1:].strip()
                description = '\n'.join(lines[1:]).strip()
            else:
                description = content
            info = {
                "description": description
            }
            response = supabase.table('problems').select('id').eq('id', problem_id).execute()
            if response.data:
                supabase.table('problems').update({
                    'name': problem_name,
                    'info': json.dumps(info, ensure_ascii=False)
                }).eq('id', problem_id).execute()
                print(f"Updated problem: {problem_id} - {problem_name}")
            else:
                supabase.table('problems').insert({
                    'id': problem_id,
                    'name': problem_name,
                    'info': json.dumps(info, ensure_ascii=False)
                }).execute()
                print(f"Inserted problem: {problem_id} - {problem_name}")
        except Exception as e:
            print(f"Error processing problem {problem_id}: {e}")
    print("Sync completed!")

if __name__ == "__main__":
    SUPABASE_URL = "SupaBase 的地址"
    SUPABASE_KEY = "SupaBase 的 service key"
    TESTDATA_PATH = "./testdata"
    sync_problems_from_markdown(SUPABASE_URL, SUPABASE_KEY, TESTDATA_PATH)
