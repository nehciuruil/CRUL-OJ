\# Trader's problem



SOLVE THIS PROBLEM TO GET A TURING'S PRIZE

