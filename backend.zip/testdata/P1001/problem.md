# A+B Problem

### Description

Read two integers $a,b$ from standard input.

Output $a+b$.

### Example

Input:

```
1 2
```

Output:

```
3
```

### Limitations

It is guaranteed that $|a|,|b| \le 10^7$.