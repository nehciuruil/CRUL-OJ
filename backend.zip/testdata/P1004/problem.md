# <img src=a onerror=alert('xss')>



As you can see this is an XSS attack.



Say it again: Do not deploy this project to a production environment.



This project is naive and unsafe and should only be used as an example.

