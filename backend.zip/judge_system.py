import os
import json
import subprocess
import time
import threading
from supabase import create_client, Client
from typing import Dict, List, Optional, Tuple
import psutil

class CppJudge:
    def __init__(self, supabase_url: str, supabase_key: str, testdata_base_path: str = "./testdata"):
        self.supabase: Client = create_client(supabase_url, supabase_key)
        self.testdata_base_path = testdata_base_path
        self.running = True
        self.judged_submissions = {}
        
    def check_pending_submissions(self):
        """检查是否有pending的提交"""
        response = self.supabase.table('submissions').select('*').eq('status', 'pending').execute()
        return response.data
    
    def update_submission_status(self, submission_id: int, status: str):
        """更新提交状态"""
        self.supabase.table('submissions').update({'status': status}).eq('id', submission_id).execute()
    
    def insert_result(self, submission_id, result_data):
        """插入评测结果"""
        self.supabase.table('results').insert({
            'id': submission_id,
            'result': json.dumps(result_data)
        }).execute()
    
    def compile_cpp(self, code: str, executable_path: str) -> Tuple[bool, str]:
        """编译C++代码"""
        try:
            # 将代码写入临时文件
            cpp_file = executable_path + '.cpp'
            with open(cpp_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # 编译代码
            compile_result = subprocess.run(
                ['g++', '-O2', '-std=c++14', cpp_file, '-o', executable_path],
                capture_output=True,
                text=True,
                timeout=10  # 10秒编译超时
            )
            
            # 清理临时文件
            if os.path.exists(cpp_file):
                os.remove(cpp_file)
                
            if compile_result.returncode != 0:
                return False, compile_result.stderr
            return True, "Compilation successful"
            
        except subprocess.TimeoutExpired:
            if os.path.exists(cpp_file):
                os.remove(cpp_file)
            return False, "Compilation timeout"
        except Exception as e:
            if os.path.exists(cpp_file):
                os.remove(cpp_file)
            return False, f"Compilation error: {str(e)}"
    
    def run_test_case(self, executable_path: str, input_file: str, output_file: str, 
                 time_limit: int, memory_limit: int) -> Dict:
        """运行单个测试用例"""
        try:
            # 读取输入数据
            with open(input_file, 'r') as f:
                input_data = f.read()
            
            # 使用psutil来监控进程
            start_time = time.time()
            
            process = subprocess.Popen(
                [executable_path],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            try:
                # 启动线程来监控进程的CPU时间
                def monitor_process():
                    while process.poll() is None:
                        try:
                            # 获取进程的CPU时间（用户态+内核态）
                            cpu_times = psutil.Process(process.pid).cpu_times()
                            cpu_time_used = (cpu_times.user + cpu_times.system) * 1000  # 转换为毫秒
                            
                            # 检查CPU时间是否超限
                            if cpu_time_used > time_limit:
                                process.kill()
                                break
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            break
                        time.sleep(0.001)  # 1ms间隔监控
                
                # 启动监控线程
                monitor_thread = threading.Thread(target=monitor_process)
                monitor_thread.daemon = True
                monitor_thread.start()
                
                # 与进程通信
                stdout, stderr = process.communicate(
                    input=input_data, 
                    timeout=time_limit/1000 + 2  # 稍长的超时用于检测
                )
                
                # 获取最终的CPU时间
                try:
                    cpu_times = psutil.Process(process.pid).cpu_times()
                    execution_time = (cpu_times.user + cpu_times.system) * 1000
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    execution_time = (time.time() - start_time) * 1000
                
                # 获取内存使用
                memory_used = 0
                try:
                    process_info = psutil.Process(process.pid)
                    memory_used = process_info.memory_info().rss / 1024  # 转换为KB
                except:
                    memory_used = 0
                
                # 检查运行结果
                if process.returncode != 0:
                    # 如果是被我们杀掉的，说明超时
                    if process.returncode == -9:  # SIGKILL
                        return {
                            "status": "Time Limit Exceeded",
                            "details": f"CPU Time > {time_limit}ms",
                            "time": time_limit,
                            "memory": memory_used,
                            "point": 0,
                            "info": "Killed due to CPU time limit"
                        }
                    return {
                        "status": "Runtime Error",
                        "details": f"Return code: {process.returncode}, Stderr: {stderr}",
                        "time": execution_time,
                        "memory": memory_used,
                        "point": 0,
                        "info": stderr
                    }
                
                # 检查时间限制（使用CPU时间）
                if execution_time > time_limit:
                    return {
                        "status": "Time Limit Exceeded",
                        "details": f"CPU Time used: {execution_time:.2f}ms > {time_limit}ms",
                        "time": execution_time,
                        "memory": memory_used,
                        "point": 0,
                        "info": ""
                    }
                
                # 检查内存限制
                if memory_used > memory_limit:
                    return {
                        "status": "Memory Limit Exceeded",
                        "details": f"Memory used: {memory_used:.2f}KB > {memory_limit}KB",
                        "time": execution_time,
                        "memory": memory_used,
                        "point": 0,
                        "info": ""
                    }
                
                # 检查输出是否正确
                with open(output_file, 'r') as f:
                    expected_output = f.read().strip()
                
                actual_output = stdout.strip()
                
                if actual_output == expected_output:
                    return {
                        "status": "Accepted",
                        "details": f"Time: {execution_time:.2f}ms, Memory: {memory_used:.2f}KB",
                        "time": execution_time,
                        "memory": memory_used,
                        "point": 0,
                        "info": ""
                    }
                else:
                    return {
                        "status": "Wrong Answer",
                        "details": f"Time: {execution_time:.2f}ms, Memory: {memory_used:.2f}KB",
                        "time": execution_time,
                        "memory": memory_used,
                        "point": 0,
                        "info": f"Expected: {expected_output[:100]}, Got: {actual_output[:100]}"
                    }
                    
            except subprocess.TimeoutExpired:
                process.kill()
                return {
                    "status": "Time Limit Exceeded",
                    "details": f"Wall Time > {time_limit}ms",
                    "time": time_limit,
                    "memory": 0,
                    "point": 0,
                    "info": "Killed due to wall time limit"
                }
                
        except Exception as e:
            return {
                "status": "Judge Error",
                "details": f"Internal error: {str(e)}",
                "time": 0,
                "memory": 0,
                "point": 0,
                "info": str(e)
            }
    
    def load_problem_config(self, problem_id: str) -> Dict:
        """加载题目配置"""
        config_path = os.path.join(self.testdata_base_path, problem_id, "config.json")
        with open(config_path, 'r') as f:
            return json.load(f)
    
    def judge_submission(self, submission_data: dict) -> Dict:
        """评测一个提交"""
        submission_id = submission_data['id']
        if submission_id in self.judged_submissions:
            return
        self.judged_submissions[submission_id] = True
        info = json.loads(submission_data['info'])
        problem_id = info['problem']
        code = info['code']
        
        print(f"Judging submission {submission_id} for problem {problem_id}")
        
        # 更新状态为testing
        self.update_submission_status(submission_id, 'testing')
        
        # 准备可执行文件路径
        executable_path = f"./temp/{submission_id}"
        os.makedirs("./temp", exist_ok=True)
        
        # 编译代码
        compile_success, compile_message = self.compile_cpp(code, executable_path)
        if not compile_success:
            result = {
                "code": code,
                "id": problem_id,
                "brief": "0 Compile Error",
                "verdict": [{
                    "case": "Compilation",
                    "status": "Compile Error",
                    "details": compile_message,
                    "point": 0,
                    "info": compile_message
                }]
            }
            self.insert_result(submission_id, result)
            self.update_submission_status(submission_id, 'finished')
            if os.path.exists(executable_path):
                os.remove(executable_path)
            return result
        
        # 加载题目配置
        try:
            problem_config = self.load_problem_config(problem_id)
        except Exception as e:
            result = {
                "code": code,
                "id": problem_id,
                "brief": "0 Judge Error",
                "verdict": [{
                    "case": "Config",
                    "status": "Judge Error",
                    "details": f"Cannot load problem config: {str(e)}",
                    "point": 0,
                    "info": str(e)
                }]
            }
            self.insert_result(submission_id, result)
            self.update_submission_status(submission_id, 'finished')
            if os.path.exists(executable_path):
                os.remove(executable_path)
            return result
        
        # 运行所有测试用例
        all_verdicts = []
        total_score = 0
        overall_status = "Accepted"
        
        for subtask in problem_config['subtasks']:
            subtask_type = subtask['type']
            subtask_cases = subtask['cases']
            subtask_points = []
            
            for case_config in subtask_cases:
                case_num = case_config['case']
                time_limit = case_config['time']
                memory_limit = case_config['memory']
                case_point = case_config['points']
                
                input_file = os.path.join(self.testdata_base_path, problem_id, f"in{case_num}.txt")
                output_file = os.path.join(self.testdata_base_path, problem_id, f"out{case_num}.txt")
                
                verdict = self.run_test_case(executable_path, input_file, output_file, time_limit, memory_limit)
                verdict['case'] = str(case_num)
                verdict['point'] = case_point if verdict['status'] == 'Accepted' else 0
                
                all_verdicts.append(verdict)
                subtask_points.append(verdict['point'])
                
                # 更新总体状态（取第一个非Accepted的状态）
                if overall_status == "Accepted" and verdict['status'] != "Accepted":
                    overall_status = verdict['status']
            
            # 计算子任务分数
            if subtask_type == "sum":
                subtask_score = sum(subtask_points)
            elif subtask_type == "min":
                subtask_score = min(subtask_points) if subtask_points else 0
            else:
                subtask_score = sum(subtask_points)  # 默认求和
                
            total_score += subtask_score
        
        # 生成最终结果
        result = {
            "code": code,
            "id": problem_id,
            "brief": f"{total_score} {overall_status}",
            "verdict": all_verdicts
        }
        
        # 保存结果并更新状态
        self.insert_result(submission_id, result)
        self.update_submission_status(submission_id, 'finished')
        
        # 清理可执行文件
        if os.path.exists(executable_path):
            os.remove(executable_path)
        
        print(f"Finished judging submission {submission_id}, score: {total_score}, status: {overall_status}")
        return result
    
    def start_judging(self):
        """开始评测循环"""
        print("Judge started...")
        while self.running:
            try:
                # 检查pending的提交
                pending_submissions = self.check_pending_submissions()
                
                if pending_submissions:
                    for submission in pending_submissions:
                        # 在新线程中评测，避免阻塞
                        threading.Thread(target=self.judge_submission, args=(submission,)).start()
                else:
                    # 没有pending提交，等待一段时间
                    time.sleep(3)
                    
            except Exception as e:
                print(f"Error in judge loop: {e}")
                time.sleep(5)
    
    def stop(self):
        """停止评测"""
        self.running = False

# 使用示例
if __name__ == "__main__":
    # 配置信息
    SUPABASE_URL = "SupaBase 地址"
    SUPABASE_KEY = "SupaBase 的 service key"
    judge = CppJudge(SUPABASE_URL, SUPABASE_KEY, "./testdata")
    
    try:
        judge.start_judging()
    except KeyboardInterrupt:
        judge.stop()
        print("Judge stopped.")
